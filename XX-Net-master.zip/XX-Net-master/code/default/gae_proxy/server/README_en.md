Uploader command line usage:    
    <code>python uploader.py "YourAppid1|YourAppid2|YourAppid3..." [-debug] [-password rc4_password]</code>    
or    
    <code>..\..\python27\1.0\python.exe uploader.py "YourAppid1|YourAppid2|YourAppid3..." [-debug] [-password rc4_password]</code>    
if you don't have python2 installed.

Note:    
* Keep the path name as server, other wise upload can't work.
* Appid support combind multi appid with |.
