
## 下载(Download)：
稳定版(Stable)：  
https://codeload.github.com/XX-net/XX-Net/zip/3.8.4


测试版(Test)：  
https://codeload.github.com/XX-net/XX-Net/zip/3.8.5


Android:  
https://github.com/XX-net/xxnet-android/releases/download/3.6.3/XX-Net-3.6.3-debug.apk
